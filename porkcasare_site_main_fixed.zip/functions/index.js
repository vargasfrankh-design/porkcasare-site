const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

const db = admin.firestore();

exports.syncTransactionToHistory = functions
  .region("us-central1")
  .firestore
  .document("usuarios/{uid}/transactions/{txId}")
  .onCreate(async (snap, context) => {
    try {
      const { uid, txId } = context.params;
      const txData = snap.data() || {};

      const entry = {
        txId,
        type: txData.type || "unknown",
        amount: txData.amount ?? null,
        timestamp: txData.timestamp ?? admin.firestore.Timestamp.now(),
        note: txData.note || txData.action || "",
        meta: txData.meta || {},
        ownerUid: txData.ownerUid || uid,
        points: txData.points ?? txData.pointsUsed ?? null
      };

      const userRef = db.collection("usuarios").doc(uid);

      await db.runTransaction(async (t) => {
        const userSnap = await t.get(userRef);
        const existingHistory = userSnap.exists ? (userSnap.data().history || []) : [];

        const already = existingHistory.some(h => h && h.txId === txId);
        if (already) {
          console.log(`Entry for tx ${txId} already present in usuarios/${uid}/history — skipping.`);
          return;
        }

        t.update(userRef, {
          history: admin.firestore.FieldValue.arrayUnion(entry)
        });
      });

      console.log(`Transaction ${txId} synced to usuarios/${uid}/history`);
      return null;
    } catch (err) {
      console.error("Error syncing transaction to history:", err);
      throw err;
    }
  });
